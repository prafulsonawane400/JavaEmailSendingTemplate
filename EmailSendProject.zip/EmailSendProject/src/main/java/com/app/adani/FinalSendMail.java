package com.app.adani;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FinalSendMail
 */
@WebServlet("/FinalSendMail")
public class FinalSendMail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FinalSendMail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("Id");
		String idFromSession = (String)request.getSession(false).getAttribute("mailCreatedId");
		System.out.println("Compare "+id+" With"+idFromSession+ " Answer is "+id.equals(idFromSession));
		if(idFromSession!=null && id!=null && id.equals(idFromSession)) {
			List<Bean> beans = (List<Bean>)request.getSession(false).getAttribute("contactsList");
			beans.forEach(bean->{
				System.out.println("Contact "+bean.getId()+" Fetched...");
			});
		}
		else {
			request.getSession(false).invalidate();
			response.sendRedirect("index.jsp");
		}
	}

}
