package com.app.adani;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


/**
 * Servlet implementation class ContactProcessing
 */
@WebServlet("/ContactProcessing")
@MultipartConfig
public class ContactProcessing extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContactProcessing() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getSession(false).invalidate();
		response.sendRedirect("index.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out = response.getWriter();
		try {
			String id = request.getParameter("id");
			if(!id.equals((String)request.getSession(false).getAttribute("mailCreatedId"))) {
				request.getSession(false).invalidate();
				response.sendRedirect("index.jsp");
			}
			Part filePart = request.getPart("file");
			FileInputStream fis = (FileInputStream)filePart.getInputStream();
			List<Bean> beans = XLSXReaderExample.extractValues(fis);
			request.setAttribute("beans", beans);
			request.setAttribute("mailCreatedId", id);
			request.getSession(false).setAttribute("contactsList", beans);
			request.getRequestDispatcher("ContactList.jsp").forward(request, response);
			  
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		}  
	}

