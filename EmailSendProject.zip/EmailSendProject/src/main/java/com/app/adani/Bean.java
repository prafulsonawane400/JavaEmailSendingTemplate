package com.app.adani;

public class Bean {

	private int id;
	
	private String customerNo;
	
	private String emailId;
	
	private String isSend;
	
	private String errorOccured;
	
	private String sendedDate;	
	

	public Bean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Bean(int id, String customerNo, String emailId, String isSend, String errorOccured, String sendedDate) {
		super();
		this.id = id;
		this.customerNo = customerNo;
		this.emailId = emailId;
		this.isSend = isSend;
		this.errorOccured = errorOccured;
		this.sendedDate = sendedDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomerNo() {
		return customerNo;
	}

	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getIsSend() {
		return isSend;
	}

	public void setIsSend(String isSend) {
		this.isSend = isSend;
	}

	public String getErrorOccured() {
		return errorOccured;
	}

	public void setErrorOccured(String errorOccured) {
		this.errorOccured = errorOccured;
	}

	public String getSendedDate() {
		return sendedDate;
	}

	public void setSendedDate(String sendedDate) {
		this.sendedDate = sendedDate;
	}
	
	
	
}
