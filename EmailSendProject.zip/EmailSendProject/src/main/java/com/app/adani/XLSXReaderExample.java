package com.app.adani;
import java.io.File;  
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;  
import org.apache.poi.xssf.usermodel.XSSFWorkbook;  
public class XLSXReaderExample {

	
	public static List<Bean> extractValues(InputStream fis) {
		List<Bean> beans = new ArrayList<Bean>();
		 Workbook adaniExcelBook = null;

		    try {
		    	adaniExcelBook = new XSSFWorkbook(fis);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		    Sheet adaniSheet = adaniExcelBook.getSheet("Sheet1");

		    //Find number of rows in excel file

		    int rowCount = adaniSheet.getLastRowNum()-adaniSheet.getFirstRowNum();

		    //Create a loop over all the rows of excel file to read it

		    for (int i = 0; i < rowCount+1; i++) {

		    	
		    	if(i!=0) {
		    	
		        Row row = adaniSheet.getRow(i);
 
                 			
		         Cell firstCell = (row.getCell(0)!=null)?row.getCell(0):null;
		         Cell secondCell = (row.getCell(1)!=null)?row.getCell(1):null;
		         Cell thirdCell = (row.getCell(2)!=null)?row.getCell(2):null;
		         Cell fourthCell = (row.getCell(3)!=null)?row.getCell(3):null;
		         Cell fifthCell = (row.getCell(4)!=null)?row.getCell(4):null;
		         Cell sixthCell = (row.getCell(5)!=null)?row.getCell(5):null;
		         
		        
		         
		         Double NumberValue = firstCell.getNumericCellValue();
		         Double customNum = secondCell.getNumericCellValue();
		         
		         Bean bean = new Bean();
		         bean.setId(NumberValue.intValue());
		         bean.setCustomerNo(""+customNum.intValue());
		         bean.setEmailId(thirdCell.getStringCellValue());
		         bean.setIsSend((fourthCell!=null)?fourthCell.getStringCellValue():null);
		         bean.setErrorOccured((fifthCell!=null)?fifthCell.getStringCellValue():null);
		         bean.setSendedDate((sixthCell!=null)?sixthCell.getStringCellValue():null);
		         beans.add(bean);
		     
		    	}
		    } 
		    return beans;
	}
	
	
	public static void main(String[] args)   
	{  
	try  
	{  
	File file = new File("/Users/crispinrozario/Downloads/file_example_XLSX_10.xlsx");   //creating a new file instance  
	FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file  
	extractValues(fis).forEach(bean->{
		System.out.println(bean.getId()+ "  "+ bean.getCustomerNo()+ " "+bean.getEmailId()+ " "+bean.getIsSend());
	});
	}
	catch(Exception e)  
	{  
	e.printStackTrace();  
	}  
	}  
}
